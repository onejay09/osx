place original AppleBacklight.kext here
