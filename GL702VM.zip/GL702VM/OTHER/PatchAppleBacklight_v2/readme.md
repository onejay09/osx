## PatchAppleBacklight from RehabMan
in case the supplied AppleBacklightInjector.kext is not working: copy the original AppleBacklight.kext from /System/Library/Extensions to the folder "vanilla" and run the script. This will create an Injector Kext for your monitor.
