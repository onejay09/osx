#!/bin/bash
DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

cp Tools/iasl /usr/bin
cp -R Tools/MaciASL.app /Applications/
cp -R Tools/EFI_Mounter-v3.app /Applications/
cp -R Tools/IORegistryExplorer.app /Applications/
cp -R Tools/Kextwizard.app /Applications/
cp Tools/iasl /Applications/MaciASL.app/Contents/MacOS/iasl61
cp -R KEXTS/ /System/Library/Extensions/
rm -rf /System/library/Extensions/AppleIntelLpssI2CController.kext
rm -rf /System/library/Extensions/AppleIntelLpssI2C.kext
rm -rf /System/library/Extensions/AppleHPM.kext

pmset -a hibernatemode 0
rm /var/vm/sleepimage
mkdir /var/vm/sleepimage
pmset -a standby 0
pmset -a autopoweroff 0
cp -R /System/Library/Extensions/AppleBacklight.kext /$DIR/OTHER/PatchAppleBacklight_v2/vanilla/
cd /$DIR/OTHER/PatchAppleBacklight_v2/
. patch.sh
cp -R /$DIR/OTHER/PatchAppleBacklight_v2/patched/ /$DIR/KEXTS/
cp -R KEXTS/ /System/Library/Extensions/
touch /System/Library/Extensions && kextcache -u /
launchctl unload -w /System/Library/LaunchAgents/com.apple.mediaanalysisd.plist
spctl --master-disable
echo "Kexts installed Caches Cleaned."