to start script open terminal and run

chmod +x setup.sh
sudo ./setup.sh


The script only sets up some variables ready for you to build your DSDT yourself.
Installs maciasl
Installs aisl iasl61 in maciasl.app
It also installs the kexts in KEXTS folder
Disables hibernate
Patches your AppleBacklight.kext and installs it in S/L/E
Deletes: AppleIntelLpssI2CController.kext
	AppleIntelLpssI2C.kext
	AppleHPM.kext
For voodooI2C
W.I.P